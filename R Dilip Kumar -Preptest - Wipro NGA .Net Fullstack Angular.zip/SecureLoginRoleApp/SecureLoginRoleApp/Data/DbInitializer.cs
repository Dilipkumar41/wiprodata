﻿using Microsoft.AspNetCore.Identity;

namespace SecureLoginRoleApp.Data
{
    public static class DbInitializer
    {
        public static async Task SeedRolesAndUsersAsync(RoleManager<IdentityRole> roleManager, UserManager<IdentityUser> userManager)
        {
            // Define roles
            string[] roles = { "Admin", "User" };

            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    await roleManager.CreateAsync(new IdentityRole(role));
                }
            }

            // Create Admin user
            var adminUser = await userManager.FindByNameAsync("admin");
            if (adminUser == null)
            {
                var newAdmin = new IdentityUser
                {
                    UserName = "admin",
                    Email = "admin@example.com",
                    EmailConfirmed = true
                };

                var result = await userManager.CreateAsync(newAdmin, "Admin@123");
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(newAdmin, "Admin");
                }
            }

            // Create Normal user
            var normalUser = await userManager.FindByNameAsync("user1");
            if (normalUser == null)
            {
                var newUser = new IdentityUser
                {
                    UserName = "user1",
                    Email = "user1@example.com",
                    EmailConfirmed = true
                };

                var result = await userManager.CreateAsync(newUser, "User@123");
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(newUser, "User");
                }

            }

        }
    }
}
