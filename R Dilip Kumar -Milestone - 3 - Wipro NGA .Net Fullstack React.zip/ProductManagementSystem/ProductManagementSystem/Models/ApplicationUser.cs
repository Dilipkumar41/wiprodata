﻿using Microsoft.AspNetCore.Identity;

namespace ProductManagementSystem.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Extra fields if needed (we’ll just keep it simple here)
       // public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
