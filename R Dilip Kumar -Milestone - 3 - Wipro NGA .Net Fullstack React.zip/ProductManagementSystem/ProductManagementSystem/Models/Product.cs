﻿using System;

namespace ProductManagementSystem.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;

        public string? PriceEncrypted { get; set; }

        // Not mapped → used only in forms & views
        [System.ComponentModel.DataAnnotations.Schema.NotMapped]
        public decimal Price { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime? UpdatedAt { get; set; }
    }
}
