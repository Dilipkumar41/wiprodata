﻿using Microsoft.AspNetCore.DataProtection;

namespace ProductManagementSystem.Services
{
    public class PriceProtectionService
    {
        private readonly IDataProtector _protector;

        public PriceProtectionService(IDataProtectionProvider provider)
        {
            _protector = provider.CreateProtector("ProductPriceProtection");
        }

        public string Protect(decimal price)
        {
            return _protector.Protect(price.ToString());
        }

        public decimal Unprotect(string protectedPrice)
        {
            return decimal.Parse(_protector.Unprotect(protectedPrice));
        }
    }
}
