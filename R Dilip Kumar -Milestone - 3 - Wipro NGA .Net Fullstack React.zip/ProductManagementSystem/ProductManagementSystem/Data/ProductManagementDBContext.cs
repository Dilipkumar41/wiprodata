﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ProductManagementSystem.Models;

namespace ProductManagementSystem.Data
{
    // DbContext integrates Identity + our Products table
    public class ProductManagementDBContext : IdentityDbContext<ApplicationUser>
    {
        public ProductManagementDBContext(DbContextOptions<ProductManagementDBContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Products { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); // Keep Identity config

            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(e => e.ProductName)
                      .IsRequired()
                      .HasMaxLength(200);

                // ✅ Map PriceEncrypted (the actual DB column)
                entity.Property(e => e.PriceEncrypted)
                      .HasColumnType("nvarchar(max)");
            });
        }
    }
}
