﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProductManagementSystem.Data;
using ProductManagementSystem.Models;
using ProductManagementSystem.Services; // ✅ PriceProtectionService

namespace ProductManagementSystem.Controllers
{
    [Authorize(Roles = "Admin,Manager")] // Only Admin/Manager can access
    public class ProductsController : Controller
    {
        private readonly ProductManagementDBContext _context;
        private readonly PriceProtectionService _priceProtector;

        public ProductsController(ProductManagementDBContext context, PriceProtectionService priceProtector)
        {
            _context = context;
            _priceProtector = priceProtector;
        }

        // GET: /Products
        public IActionResult Index()
        {
            var products = _context.Products.ToList();

            // Decrypt before showing
            foreach (var product in products)
            {
                if (!string.IsNullOrEmpty(product.PriceEncrypted))
                {
                    product.Price = _priceProtector.Unprotect(product.PriceEncrypted);
                }
            }

            return View(products);
        }

        // GET: /Products/Create (Admin only)
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Products/Create (Admin only)
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                product.PriceEncrypted = _priceProtector.Protect(product.Price);
                product.CreatedAt = DateTime.Now;

                _context.Products.Add(product);
                _context.SaveChanges();

                TempData["Message"] = $"Product \"{product.ProductName}\" has been successfully created!";
                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }

        // GET: /Products/Edit/{id} (Admin + Manager)
        [Authorize(Roles = "Admin,Manager")]
        public IActionResult Edit(int id)
        {
            var product = _context.Products.Find(id);
            if (product == null) return NotFound();

            // Decrypt price before showing in form
            if (!string.IsNullOrEmpty(product.PriceEncrypted))
            {
                product.Price = _priceProtector.Unprotect(product.PriceEncrypted);
            }

            return View(product);
        }

        // POST: /Products/Edit/{id} (Admin + Manager)
        [HttpPost]
        [Authorize(Roles = "Admin,Manager")]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Product product)
        {
            if (id != product.ProductId) return NotFound();

            if (ModelState.IsValid)
            {
                var existingProduct = _context.Products.Find(id);
                if (existingProduct == null) return NotFound();

                // Always allow name change
                existingProduct.ProductName = product.ProductName;

                // Encrypt price again if Admin, or just keep old if Manager
                if (User.IsInRole("Admin"))
                {
                    existingProduct.PriceEncrypted = _priceProtector.Protect(product.Price);
                }

                existingProduct.UpdatedAt = DateTime.Now;

                _context.Products.Update(existingProduct);
                _context.SaveChanges();

                TempData["Message"] = $"Product \"{existingProduct.ProductName}\" has been successfully updated!";
                return RedirectToAction(nameof(Index));
            }

            return View(product);
        }

        // GET: /Products/Delete/{id} (Admin only)
        [Authorize(Roles = "Admin")]
        public IActionResult Delete(int id)
        {
            var product = _context.Products.Find(id);
            if (product == null) return NotFound();

            // Decrypt before showing
            if (!string.IsNullOrEmpty(product.PriceEncrypted))
            {
                product.Price = _priceProtector.Unprotect(product.PriceEncrypted);
            }

            return View(product);
        }

        // POST: /Products/Delete/{id} (Admin only)
        [HttpPost, ActionName("Delete")]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var product = _context.Products.Find(id);
            if (product == null) return NotFound();

            _context.Products.Remove(product);
            _context.SaveChanges();

            TempData["Message"] = $"Product \"{product.ProductName}\" has been deleted!";
            return RedirectToAction(nameof(Index));
        }
    }
}
